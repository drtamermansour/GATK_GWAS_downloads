source("man_plot.R")
library(RColorBrewer)

args <- commandArgs(trailingOnly=TRUE)
args

#read in files
print("Reading in meta-analysis table")
metaFile <- read.delim(args[1], stringsAsFactors = F, header = T)
PCa_396 <- read.delim("prostate_396.assoc.logistic", stringsAsFactors = F)

#get chromosome and location
prostate <- merge(metaFile, PCa_396[,1:3], by.x = "MarkerName", by.y = "SNP", all.x = T, all.y = F)

col <- brewer.pal(9,"Set1")
chroms <- c(1:22, 23, 25)
chromlabels <- as.character(chroms)
alldata <- subset(prostate, !(CHR %in% c(0,NA)))

# create Manhatton Plot
print("plotting")
png(file=paste(args[1], ".allChrs.manhattan.png", sep = ""), width=6.5, height=5, units="in", pointsize=10, res=600)
par(las = 1)
man_plot(alldata[ ,c("CHR","BP","P.value")], cutoffs = c(0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20), siglines=3e-8, sigcolors="blue", pch=19, cex=0.4, color=col, chrom=chroms, labels=chromlabels)
par(las = 0)
dev.off()


