"man_plot" <-
  function (data, 
            logscale = TRUE, 
            base = 10, 
            cutoffs = c(3, 5, 7, 9),
            siglines = NULL,
            sigcolors = "red", 
            color = sample(colors(), 26),
            chrom = as.character(c(1:22,"X","Y","XY","MT")),
            startbp = NULL,
            endbp = NULL,
            labels = as.character(c(1:22,"X","Y","XY","MT")),
            xlabel = "Chromosome",
            ylabel = "-Log10(p-value)", ...) 
  {
    if (any(is.na(data)))
      data <- data[-unique(which(is.na(data))%%nrow(data)),]
    keep <- which(data[,1] %in% chrom)
    data <- data[keep,]
    if (!is.null(startbp) & !is.null(endbp) & length(chrom) == 1){
      keep <- which(data[,2] >= startbp & data[,2] <= endbp) 
      data <- data[keep,]       
    }
    
    
    chr  <- data[, 1]
    pos  <- data[, 2]
    p    <- data[, 3]
    
    ### remove any NAs
    which(is.na(data[,2]))
    chr  <- replace(chr,which(chr == "X"),"100")
    chr  <- replace(chr,which(chr == "Y"),"101")
    chr  <- replace(chr,which(chr == "XY"),"102")
    chr  <- replace(chr,which(chr == "MT"),"103")	
    
    ord  <- order(as.numeric(chr),as.numeric(pos))
    chr  <- chr[ord]
    pos  <- pos[ord]
    p    <- p[ord]
    
    lens.chr <- as.vector(table(as.numeric(chr)))
    CM <- cumsum(lens.chr)
    n.markers <- sum(lens.chr)
    n.chr <- length(lens.chr)
    id <- 1:n.chr
    color <- rep(color,ceiling(n.chr/length(color)))
    if (logscale)
      p <- -log(p,base)        
    if ( any(diff(pos) < 0) ) {
      cpos <-  cumsum(c(0,pos[which(!duplicated(chr))-1]))
      pos <- pos + rep(cpos,lens.chr)
      
      mids <- cpos + diff(c(cpos,max(pos)))/2
    } else {
      mids <- max(pos)/2
    }
    
    par(xaxt = "n", yaxt = "n")
    plot(c(pos,pos[1]), c(9,p), type = "n", xlab = xlabel, ylab = ylabel, axes = FALSE,  ...)
    for (i in 1:n.chr) {
      u <- CM[i]
      l <- CM[i] - lens.chr[i] + 1
      cat("Plotting points ", l, "-", u, "\n")
      points(pos[l:u], p[l:u], col = color[i], ...)
    }
    par(xaxt = "s", yaxt = "s")
    axis(1, at = c(0, pos[round(CM)],max(pos)),FALSE)
    text(mids, par("usr")[3] - 0.5, srt = 0, pos=2,cex=0.5,offset= -0.2,
         labels = labels[1:n.chr], xpd = TRUE)
    axis(side=2, at = cutoffs )
    if (!is.null(siglines))
      abline(h = -log(siglines,base),col=sigcolors)
    
  }

